Info:
After importing the REG file, in context menu of exe/bat/cmd files, you may press Q to run as QuickAdmin. This is ideal for those who prefer to work with keyboard.

How to install:
Simply double-click on "Q for QA.reg" to import the REG file, then you are done.
This REG is suitable for QuickAdmin version 3.x.